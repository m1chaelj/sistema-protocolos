package mx.com.Escom_TT.util.error;

public enum ErrorType {
    FIELD,
    REQUEST
}
