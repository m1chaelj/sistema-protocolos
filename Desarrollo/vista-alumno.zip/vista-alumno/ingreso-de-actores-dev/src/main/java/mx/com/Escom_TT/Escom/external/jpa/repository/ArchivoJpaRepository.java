package mx.com.Escom_TT.Escom.external.jpa.repository;

import mx.com.Escom_TT.Escom.external.jpa.model.ArchivoJpa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArchivoJpaRepository extends JpaRepository<ArchivoJpa, Integer> {
}
