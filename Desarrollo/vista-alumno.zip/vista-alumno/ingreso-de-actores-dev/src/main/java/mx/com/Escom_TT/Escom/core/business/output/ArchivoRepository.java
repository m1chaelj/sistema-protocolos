package mx.com.Escom_TT.Escom.core.business.output;

import mx.com.Escom_TT.Escom.core.entity.Archivo;

public interface ArchivoRepository {
    Archivo save(Archivo archivo);
}
